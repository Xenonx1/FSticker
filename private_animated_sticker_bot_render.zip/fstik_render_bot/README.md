# Private Animated Sticker Bot (Render + Neon)

A private Telegram bot that converts GIFs and videos into Telegram **video stickers** (`.webm`, VP9) and creates/manages sticker packs. It does not implement custom emoji.

## Features

- Private access: only `OWNER_ID`, in a private chat, can use the bot.
- Convert Telegram GIF/animation and video uploads to VP9 WebM video stickers.
- Create a sticker pack with `/newpack Pack Name`.
- Add more stickers to the active pack by sending more GIFs/videos.
- Select an existing pack with `/add PackName`.
- List packs with `/packs`.
- Finish a pack session with `/done`.
- Persistent pack metadata in Neon PostgreSQL.
- Original sticker files and packs are stored by Telegram, not on Render's ephemeral disk.

## Important Telegram limits

Telegram video stickers use VP9 WebM, no audio, maximum 3 seconds, up to 30 FPS, one side exactly 512 pixels, and maximum 256 KB. The bot takes the first three seconds and attempts multiple compression bitrates. Some inputs cannot be compressed sufficiently; those will be rejected with an explanation.

This bot makes **video stickers**, not Lottie `.tgs` animated stickers. Telegram treats those as different formats.

## 1. Create the Telegram bot

1. Open `@BotFather` in Telegram.
2. Send `/newbot` and follow its instructions.
3. Copy the bot token. Keep it secret.
4. Open `@userinfobot` or another trusted ID bot to find your numeric Telegram user ID.
5. Do not add the bot to groups. It is designed for private-chat use.

If you previously shared a bot token in a public place or chat, revoke it in BotFather and use a new one.

## 2. Create the Neon database

1. Sign in at https://neon.com/.
2. Create a project (PostgreSQL).
3. Open **Connect** and copy the connection string.
4. Use the pooled connection string if Neon offers one.
5. Keep `sslmode=require` in the connection string.
6. Do not share the connection string publicly.

The bot creates its own tables on first startup.

## 3. Put the project on GitHub

1. Download and extract this ZIP.
2. Sign in to https://github.com/ and create a new **private** repository.
3. Upload all extracted files and folders, preserving the structure.
4. Commit the files.

Never upload `.env` files, bot tokens, database passwords, or other secrets.

## 4. Deploy on Render

1. Sign in at https://render.com/.
2. Choose **New + → Web Service**.
3. Connect your private GitHub repository.
4. Select the Docker runtime (Render detects the `Dockerfile`).
5. Choose the **Free** instance.
6. Add these environment variables:

| Key | Value |
|---|---|
| `BOT_TOKEN` | Token from BotFather |
| `OWNER_ID` | Your numeric Telegram user ID |
| `DATABASE_URL` | Neon PostgreSQL connection string |
| `WEBHOOK_SECRET` | A long random string (32+ characters) |

Render supplies `RENDER_EXTERNAL_URL` and `PORT` automatically. Do not manually set `RENDER_EXTERNAL_URL` unless you have a specific reason.

7. Click **Create Web Service** and wait for the first deployment.
8. Open the service URL. It should show `{"ok":true,...}`.
9. Open the bot in Telegram and send `/start`.

The bot registers its Telegram webhook automatically at startup.

## 5. Use the bot

### Create a pack

Send:
`/newpack My Reactions`

Then send a GIF or video. The bot converts it and creates a Telegram sticker pack. Send more GIFs/videos to add them to the same pack.

### Add to an existing pack

Send:
`/add My Reactions`

Then send GIFs/videos.

### Other commands

- `/packs` — list packs and links.
- `/done` — stop adding to the current pack.
- `/cancel` — cancel a pending new pack.
- `/help` — instructions.

## Free-tier caveats

- Render Free web services spin down after 15 minutes without inbound traffic. The next Telegram update may experience a cold start (often around a minute).
- Render free filesystems are ephemeral. This project only uses `/tmp` for temporary conversion and keeps persistent metadata in Neon; Telegram stores the actual stickers.
- Neon Free has compute/storage quotas. Check your Neon usage dashboard.
- Free hosting is suitable for personal/testing use, not guaranteed production uptime.

## Troubleshooting

### Render says `BOT_TOKEN` is missing
Check the environment variable spelling and redeploy.

### Bot says it cannot compress the media
Try a shorter clip (under 3 seconds), smaller dimensions, or a simpler GIF. Telegram enforces a 256 KB maximum for video stickers.

### Webhook is not working
Check Render logs. Confirm the service is live, `BOT_TOKEN` is correct, and the service root URL responds with `{"ok":true}`. The bot configures the webhook on every startup.

### Database connection error
Use the Neon connection string with SSL enabled (`sslmode=require`). Ensure there are no missing characters in `DATABASE_URL`.

### Pack name is occupied
The bot automatically retries with a short random suffix. If a pack was created in Telegram but the service stopped before saving its database record, check `/packs` and your Telegram sticker packs before retrying.
